Name: Zhicheng Li
Section: 21770
UFL Email: zli5@ufl.edu
System: Windows 11 (64 bit architecture)
Compiler: g++.exe (x86_64-posix-seh-rev0, Built by MinGW-W64 project) 7.3.0
SFML version: SFML 2.5.1
IDE: Clion
Other notes: None